﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class test11Controller : MonoBehaviour {
	// 장치 인식 및 사용을 위해.
	private SteamVR_TrackedObject Obj;
	private SteamVR_Controller.Device device;
	private Valve.VR.EVRButtonId TriggerButton = Valve.VR.EVRButtonId.k_EButton_SteamVR_Trigger;
	// 트리거 버튼 
	public bool TriggerButtonDown = false;
	void Start () 
	{
		Obj = GetComponent<SteamVR_TrackedObject> ();
	}
	void Update () 
	{
    // 장치에 할당 
		device = SteamVR_Controller.Input ((int)Obj.index);
		TriggerButtonDown = device.GetPressDown (TriggerButton);
		if (TriggerButtonDown) {
			Debug.Log (" 트리거 버튼 눌려짐.");
			ClickMove ();
		}
	}
	void ClickMove()
	{
		// 컨트롤러의 부모 오브젝트인 CameraRig 의 transform을 저장한다.
		Transform CameraRigPos = Obj.transform.parent; //SteamVR_Render.Top().origin; 
		//Debug.Log (" Toppos = " + Toppos + " org = " + Obj.transform.parent);
		float Dist = 0f;    
		RaycastHit hit;
		// Ray 의 위치와 방향을 컨트롤러로 부터 나오도록 정해준다. 
		Ray ray = new Ray(transform.position, transform.forward);	
		if (Physics.Raycast(ray, out hit)) {                        
			// 충돌 되는 위치와의 거리를 계산하고 
			Dist = hit.distance;
			// Camera(eye) 위치를 저장한다. 
			Vector3 CameraEyePos = new Vector3 (SteamVR_Render.Top ().head.position.x, CameraRigPos.position.y, SteamVR_Render.Top ().head.position.z);
			// 새로 움직일 위치를 계산한다. 
			CameraRigPos.position = CameraRigPos.position + (ray.origin + (ray.direction  * Dist)) - CameraEyePos;
		}
	} 
}
