﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreCount : MonoBehaviour {

	private Text scoreText;
	public static int Score;

	void Start () {
		scoreText = GetComponent<Text> ();	
		Score = 0;
	}
	public void AddScore()
	{
		Score++;
	}
	void Update () {
		scoreText.text = "Score : " + Score;
	}
}
