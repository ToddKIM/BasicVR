﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EffectSound : MonoBehaviour {

	AudioSource PointSound;

	void Start () {
		PointSound = GetComponent<AudioSource> ();
		PointSound.Play();
	}

}
