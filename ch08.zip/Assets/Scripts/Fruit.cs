using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fruit : MonoBehaviour {
	public float startForce;
	Rigidbody rb;
	public GameObject BoxSlicedPrefab;
	ScoreCount scount = new ScoreCount ();

	void Start ()
	{
		rb = GetComponent<Rigidbody>();
		rb.AddForce (transform.up * startForce, ForceMode.Impulse);		
	}

	void OnTriggerEnter (Collider col)
	{
		if (col.tag == "Blade")
		{
			GameObject SlicedFruit = Instantiate(BoxSlicedPrefab, transform.position, transform.rotation);	
			Destroy(SlicedFruit, 3f);
			Destroy(gameObject);	
			scount.AddScore ();
		}
	}
}
