using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FruitSpawner : MonoBehaviour {

	public GameObject FruitPrefab;
	public Transform[] SpawnPoints;

	public float minDelay = 0.1f;
	public float maxDelay = 1f;
	public float DestroyDelay = 5f;
	private IEnumerator coroutine;

	void Start () 
	{
		coroutine = SpawnFruits(DestroyDelay);
		StartCoroutine(coroutine);
	}

	IEnumerator SpawnFruits (float DDelay)
	{
		while (true)
		{
			float delay = Random.Range (minDelay, maxDelay);
			yield return new WaitForSeconds(delay);

			int SpawnIndex = Random.Range(0, SpawnPoints.Length);
			Transform SpawnPoint = SpawnPoints[SpawnIndex];

			GameObject SpawnedFruit = Instantiate(FruitPrefab, SpawnPoint.position, SpawnPoint.rotation);
			Destroy(SpawnedFruit, DDelay);
		}
	}	
}
