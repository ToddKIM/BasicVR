﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class test4Controller : MonoBehaviour {

	private SteamVR_TrackedObject Obj;
	private SteamVR_Controller.Device device;
	private Valve.VR.EVRButtonId TouchpadButton = Valve.VR.EVRButtonId.k_EButton_SteamVR_Touchpad;

	public bool TouchpadButtonDown = false;

	void Start () 
	{
		Obj = GetComponent<SteamVR_TrackedObject> ();
	}
	void Update () 
	{
		device = SteamVR_Controller.Input ((int)Obj.index);
		TouchpadButtonDown = device.GetPressDown (TouchpadButton);
		if (TouchpadButtonDown) {
			Debug.Log (" TouchpadButtonDown 눌려짐.");
		}
	} 

}
