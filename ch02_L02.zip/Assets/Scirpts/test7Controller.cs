﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class test7Controller : MonoBehaviour {

	private SteamVR_TrackedObject Obj;
	private SteamVR_Controller.Device device;
	private Valve.VR.EVRButtonId TouchpadButton = Valve.VR.EVRButtonId.k_EButton_SteamVR_Touchpad;

	public float TpX;
	public float TpY;
	public bool TouchpadButtonPressed = false;
	private ushort HapticPower = 500;
	void Start () 
	{
		Obj = GetComponent<SteamVR_TrackedObject> ();
	}
	void Update () 
	{
		device = SteamVR_Controller.Input ((int)Obj.index);
		TouchpadButtonPressed = device.GetPress (TouchpadButton);
		TpX = device.GetAxis (TouchpadButton).x;
		TpY = device.GetAxis (TouchpadButton).y;
		if (TouchpadButtonPressed) {
			if ((TpY > 0.3f) && (TpX > 0.3f)) {
				Debug.Log ("Up&Right");
				device.TriggerHapticPulse (HapticPower);
			} else if ((TpY < -0.3f) && (TpX > 0.3f)) {
				Debug.Log ("Down&Right");
			} else if ((TpY < -0.3f) && (TpX < -0.3f)) {
				Debug.Log ("Down&Left");
			} else {
				Debug.Log ("Up&Left");
			}
		} 
	} 

}
