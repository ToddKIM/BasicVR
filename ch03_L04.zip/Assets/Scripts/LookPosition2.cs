﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LookPosition2 : MonoBehaviour {

	public Camera camera;
	public GameObject Ground;

	Ray ray;
	RaycastHit hit;

	public GameObject PointObj;
	public Vector3 MovePoint;

	void Update () {

		ray.origin = camera.transform.position;
		ray.direction = camera.transform.forward;

		if (Physics.Raycast (ray, out hit)) {
			if (hit.collider.gameObject == Ground) {
			
				PointObj.transform.position = hit.point;
				MovePoint = hit.point;
			}
		}

	}
}
