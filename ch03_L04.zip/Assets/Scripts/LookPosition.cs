﻿using UnityEngine;
using System.Collections;
using UnityEngine.AI;

public class LookPosition : MonoBehaviour {
	public Camera camera;
	public GameObject Ground;

	NavMeshAgent agent;

	Ray ray;
	RaycastHit hit;

	void Start()
	{
		agent = GetComponent<NavMeshAgent> ();
	}

	void Update () {
		
		ray.origin = camera.transform.position;
		ray.direction = camera.transform.forward;

		if (Physics.Raycast (ray, out hit)) {
			if (hit.collider.gameObject == Ground) {

				Debug.Log ("hit point = " + hit.point);
				agent.SetDestination(hit.point);
			}
		}

	}

//		Ray ray;
//		RaycastHit hit;
//		GameObject hitObject;
//
//		Debug.DrawRay (camera.transform.position, camera.transform.rotation * Vector3.forward * 100.0f);
//
//		ray = new Ray (camera.transform.position, camera.transform.rotation * Vector3.forward);
//		if (Physics.Raycast (ray, out hit)) {
//			hitObject = hit.collider.gameObject;
//			if (hitObject == ground) {
//				Debug.Log ("Hit (x,y,z): " + hit.point.ToString("F2"));
//				transform.position = hit.point;
//			}
//		}

/*
		Ray ray;
		RaycastHit[] hits;
		GameObject hitObject;
		
		Debug.DrawRay (camera.transform.position, camera.transform.rotation * Vector3.forward * 100.0f);
		
		ray = new Ray (camera.transform.position, camera.transform.rotation * Vector3.forward);
		hits = Physics.RaycastAll (ray);
		for (int i=0; i < hits.Length; i++) {
			RaycastHit hit = hits [i];
			hitObject = hit.collider.gameObject;
			if (hitObject == ground) {
				Debug.Log ("Hit (x,y,z): " + hit.point.ToString("F2"));
				transform.position = hit.point;
			}
		}
	}
*/	

}
