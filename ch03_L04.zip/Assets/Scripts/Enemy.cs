﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour {

	private float RX;
	private float RZ; 
	public Vector3 Pos;

	public Transform ProgressBar;
	public Transform CameraPos;
	void Start () {
		SetPositionXZ ();

	}
	

	void Update () {
		LookCamera ();
		if (Vector3.Distance (transform.position,Pos) < 2f) {
			SetPositionXZ ();
		}
		Quaternion Rot = Quaternion.LookRotation (Pos - transform.position);
		transform.rotation = Quaternion.Slerp (transform.rotation, Rot, 3*Time.deltaTime);
		transform.Translate (new Vector3 (0, 0, 3 * Time.deltaTime));
	}

	void SetPositionXZ()
	{
		RX = Random.Range (-10f, 10f);
		RZ = Random.Range (-10f, 10f);

		Pos = new Vector3 (RX, 1f, RZ);
	}

	void LookCamera()
	{
		ProgressBar.LookAt (CameraPos);
		ProgressBar.Rotate (0f, 180f, 0f);
	}
}
