﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LookPosition3 : MonoBehaviour {

	public Camera camera;
	public GameObject Ground;

	Ray ray;
	RaycastHit hit;

	public GameObject PointObj;

	private GameObject Obj;
	public GameObject CubeObj;


	public GameObject SliderObj;
	Slider sd;

	void Start()
	{

		sd = SliderObj.GetComponent<Slider> ();
	}

	void Update () {

		ray.origin = camera.transform.position;
		ray.direction = camera.transform.forward;

		if (Physics.Raycast (ray, out hit)) {
			
			if (hit.collider.gameObject == Ground) {

				PointObj.transform.position = hit.point;
	
			}

			if (hit.collider.gameObject.tag == "RedTag") {
				Obj = hit.collider.gameObject;
				Obj.GetComponent<Renderer> ().material.color = Color.yellow;
			}

			if (hit.collider.gameObject.tag == "GreenTag") {
				Instantiate (CubeObj);
			}

			if (hit.collider.gameObject.tag == "BlueTag") {
				Obj = hit.collider.gameObject;

				Obj.GetComponent<Rigidbody> ().useGravity = true;
				Obj.GetComponent<Rigidbody> ().AddForce (Obj.transform.forward * 2000);
			}

			if (hit.collider.gameObject.tag == "EnemyTag") {				
				sd.value--;
			}
		}

	}
}
