using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallSpawner : MonoBehaviour {

	public GameObject BaseBallPrefab;
	public Transform SpawnPoint;

	public float minDelay = 0.1f;
	public float maxDelay = 1f;
	public float DestroyDelay = 5f;
	private IEnumerator coroutine;



	void Start () 
	{
		coroutine = SpawnBalls(DestroyDelay);
		StartCoroutine(coroutine);
	}

	IEnumerator SpawnBalls (float DDelay)
	{
		while (true)
		{
			float delay = Random.Range (minDelay, maxDelay);
			yield return new WaitForSeconds(delay);

			GameObject SpawnedBall = Instantiate(BaseBallPrefab, SpawnPoint.position, SpawnPoint.rotation);		

			Destroy(SpawnedBall, DDelay);
		}
	}	
}




