﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour {
	
	Rigidbody rb;
	public GameObject SlicedPrefab;

	void Start ()
	{
		rb = GetComponent<Rigidbody>();
	}

	void OnTriggerEnter (Collider col)
	{
		if (col.tag == "Bullet")
		{
			DestroyBall ();					
		}
	}

	public void DestroyBall()
	{
		GameObject slicedObj = Instantiate (SlicedPrefab, transform.position, transform.rotation);
		Destroy(slicedObj, 3f);
		Destroy(gameObject);	
	}

}
