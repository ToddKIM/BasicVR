﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BulletCount : MonoBehaviour {

	private Text scoreText;
	public static int bulletCnt;

	void Start () {
		scoreText = GetComponent<Text> ();	
		bulletCnt = 12;
	}
	public void DecCnt()
	{
		bulletCnt--;
	}

	public int GetbulletCnt
	{
		get
		{
			return bulletCnt;
		}
		set
		{

			bulletCnt = value;
		}
	}

	void Update () {
		scoreText.text = "bullet : " + bulletCnt;
	}
}
