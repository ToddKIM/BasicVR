﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlingshotBand : MonoBehaviour {

	public LineRenderer Acube;
	public LineRenderer Bcube;

	public GameObject StartPoint;

	void Start () {
		InitBand ();	
	}
	void Update () {
		Acube.SetPosition (1, StartPoint.transform.position);
		Bcube.SetPosition (1, StartPoint.transform.position);
	}

	void InitBand()
	{
		Acube.SetPosition (0, Acube.transform.position);
		Bcube.SetPosition (0, Bcube.transform.position);
	}
}
