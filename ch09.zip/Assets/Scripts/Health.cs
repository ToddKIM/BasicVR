﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Health : MonoBehaviour {

	private Slider sd;
	public static float healthvalue;

	private float timeRemaining = 100f;

	BulletCount bCntInst = new BulletCount ();

	void Start () {
		sd = GetComponent<Slider> ();
		healthvalue = sd.value;
	}

	public void decValue()
	{		
		if (healthvalue < 0) {
			healthvalue = 0;
		} else {
			healthvalue--;
		}
	}

	public bool checkDestroy()
	{
		if (healthvalue == 0) {
			return true;
		} else {
			return false;
		}
	}

	void Update () {
		sd.value = healthvalue;	

		timeRemaining -= Time.deltaTime;
		TimeRemainingDisplay();
		if (timeRemaining <= 0f)
		{
			EndRound();
		}

		int bCnt; 
		bCnt = bCntInst.GetbulletCnt;
		if (bCnt < 0) 
		{
			EndRound();
		}
	}


	private void TimeRemainingDisplay()
	{
		
		sd.value = Mathf.Round (timeRemaining);
	}

	void EndRound()
	{
		Application.LoadLevel (Application.loadedLevel);
	}

}
