﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Slingshot : MonoBehaviour {

	//slingshotball prefab을 가져온다.
	public GameObject SlingShotBallPrefab;
	//위치 
	public GameObject BallPoint;

	// 스폰 된 ball
	private GameObject SpawnedBall;
	// 준가 됬는지 확인 
	private bool ReadyFlg = true;

	// 컨트롤러 
	private SteamVR_TrackedObject trackedController;

	// 현재 충돌 중인지 
	private bool ChKSlingShotFlg = false;

	// 원상 복귀를 위한 slingshot 처음 위치 
	private Vector3 SlingShotStart;

	BulletCount bulletCnt = new BulletCount ();

	void Start () {		
		// 처음 위치 저장 
		SlingShotStart = BallPoint.transform.position;
	}

	void Update () {	

		if (ReadyFlg) {
			SpawnedBall = Instantiate (SlingShotBallPrefab);
			SpawnedBall.transform.parent = BallPoint.transform;
			SpawnedBall.transform.localPosition = Vector3.zero;
			ReadyFlg = false;
		}

		if (trackedController != null) {
			// 컨트롤러가 존재한다. 
			var device = SteamVR_Controller.Input ((int)trackedController.index);
			// 충돌 중인가?
			if (ChKSlingShotFlg) {

				// Trigger 버튼을 계속 누르고 있는가?
				if (device.GetTouch (SteamVR_Controller.ButtonMask.Trigger)) {
					// 누르고 있는 동안의 컨트롤러 위치를  ball 위치에 넣는다. 
					BallPoint.transform.position = trackedController.transform.position;
				}
				// Trigger 버튼이 눌림이 떨어 졌는가? 
				else if (device.GetTouchUp (SteamVR_Controller.ButtonMask.Trigger)) {
					ReadyFlg = true;
					ChKSlingShotFlg = false;

					// 우선 스폰 된 ball 의 vector3를 저장.
					Vector3 ballPos = SpawnedBall.transform.position;

					// ball 위치를 원상태로 돌린다. 
					BallPoint.transform.position = SlingShotStart;
					SpawnedBall.transform.parent = null;

					Rigidbody rb = SpawnedBall.GetComponent<Rigidbody> ();
					// velocity를 적용해서 날아 가도록 만든다. 
					rb.velocity = (SlingShotStart - ballPos) * 15f;
					// 중력도 적용 한다.
					rb.useGravity = true;

					bulletCnt.DecCnt ();
				}  

			}
		}
	}

	// 컨트롤러와 시작 포인트의 충돌
	void OnTriggerEnter(Collider other)
	{
		trackedController = other.GetComponent<SteamVR_TrackedObject> ();
		if (trackedController != null) {

			ChKSlingShotFlg = true;
		}

	}

	// 컨트롤러와 시작 포인트의 충돌 해제 
	void OnTriggerExit(Collider other)
	{
		trackedController = other.GetComponent<SteamVR_TrackedObject> ();
		if (trackedController != null) {

			ChKSlingShotFlg = false;
		}

	}
}
