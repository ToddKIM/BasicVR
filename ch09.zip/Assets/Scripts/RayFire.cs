﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RayFire : MonoBehaviour {

	private SteamVR_TrackedObject Obj;
	private SteamVR_Controller.Device device;
	private Valve.VR.EVRButtonId TouchpadButton = Valve.VR.EVRButtonId.k_EButton_SteamVR_Touchpad;
	private Valve.VR.EVRButtonId TriggerButton = Valve.VR.EVRButtonId.k_EButton_SteamVR_Trigger;

	public bool TriggerButtonDown = false;
	public bool TriggerButtonUp = false;
	public bool TriggerButtonPressed = false;

	private ushort HapticPower = 800;

	public Rigidbody BulletObj;
	public Transform BulletPos;

	BulletCount bulletCnt = new BulletCount ();


	public Transform RayPos;

	public Color c1 = Color.yellow;

	// Start() 함수에서 Addcomponent로 만들어준 LineRenderer를 다시 불러옮.
	LineRenderer lineRenderer; 

	Ray ray;
	RaycastHit hit;


	void Start () 
	{
		Obj = GetComponent<SteamVR_TrackedObject> ();

		// 컴포넌트를 첨부하기 위함. 
		lineRenderer = gameObject.AddComponent<LineRenderer>();
		// 기본 material 을 정해 주어야 보라색으로 안 보임.
		lineRenderer.material = new Material(Shader.Find("Particles/Additive"));
		// 선의 시작 색
		lineRenderer.startColor = c1;
		// 선의 끝 색
		lineRenderer.endColor = c1;

	}

	void Update () 
	{
		device = SteamVR_Controller.Input ((int)Obj.index);

		TriggerButtonDown = device.GetPressDown (TriggerButton);
		TriggerButtonUp = device.GetPressUp (TriggerButton);
		TriggerButtonPressed = device.GetPress(TriggerButton);
		if (TriggerButtonDown) {
			Debug.Log (" 트리거 버튼 눌려짐.");
			FireObj ();
		}

		if (TriggerButtonUp) {
			// 선의 너비를 결정함.
			lineRenderer.widthMultiplier = 0f;		
		}

		if (TriggerButtonPressed) {

			Haptic ();		
		}
	}

	private void Haptic()
	{
		device.TriggerHapticPulse (HapticPower);
	}

	private void FireObj()
	{
		// 선의 너비를 결정함.
		lineRenderer.widthMultiplier = 0.01f;
		// 시작은 자신의 위치 
		lineRenderer.SetPosition (0,BulletPos.position);
		// 끝은 목표 위치.
		lineRenderer.SetPosition (1,RayPos.position );


		ray.origin = BulletPos.position;
		ray.direction = BulletPos.forward;

		if (Physics.Raycast (ray, out hit)) {
			if (hit.collider.tag == "Ball") {
				Debug.Log ("hit");

				Ball bl = hit.collider.GetComponent<Ball> ();

				bl.DestroyBall ();
			}
		}
		bulletCnt.DecCnt ();
	} 

}
