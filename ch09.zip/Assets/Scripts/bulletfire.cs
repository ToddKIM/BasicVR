﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bulletfire : MonoBehaviour {

	private SteamVR_TrackedObject Obj;
	private SteamVR_Controller.Device device;
	private Valve.VR.EVRButtonId TouchpadButton = Valve.VR.EVRButtonId.k_EButton_SteamVR_Touchpad;
	private Valve.VR.EVRButtonId TriggerButton = Valve.VR.EVRButtonId.k_EButton_SteamVR_Trigger;

	public bool TriggerButtonDown = false;
	public bool TriggerButtonUp = false;
	public bool TriggerButtonPressed = false;

	private ushort HapticPower = 800;

	public Rigidbody BulletObj;
	public Transform BulletPos;

	BulletCount bulletCnt = new BulletCount ();

	void Start () 
	{
		Obj = GetComponent<SteamVR_TrackedObject> ();
	}

	void Update () 
	{

		device = SteamVR_Controller.Input ((int)Obj.index);

		TriggerButtonDown = device.GetPressDown (TriggerButton);
		TriggerButtonUp = device.GetPressUp (TriggerButton);
		TriggerButtonPressed = device.GetPress(TriggerButton);
		if (TriggerButtonDown) {
			Debug.Log (" 트리거 버튼 눌려짐.");
			FireObj ();

		}

		if (TriggerButtonPressed) {

			Haptic ();		
		}
	}

	private void Haptic()
	{
		device.TriggerHapticPulse (HapticPower);
	}

	private void FireObj()
	{
		Rigidbody bulletIns;

		bulletIns = Instantiate (BulletObj,BulletPos.position,BulletPos.rotation) as Rigidbody;

		bulletIns.AddForce (BulletPos.forward * 2000);

		bulletCnt.DecCnt ();
	} 

}
