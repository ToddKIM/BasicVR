﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class test10Controller : MonoBehaviour {

	private SteamVR_TrackedObject Obj;
	private SteamVR_Controller.Device device;
	private Valve.VR.EVRButtonId TouchpadButton = Valve.VR.EVRButtonId.k_EButton_SteamVR_Touchpad;
	private Valve.VR.EVRButtonId TriggerButton = Valve.VR.EVRButtonId.k_EButton_SteamVR_Trigger;

	public float TpX;
	public float TpY;

	public bool TriggerButtonDown = false;
	public bool TriggerButtonUp = false;
	public bool TriggerButtonPressed = false;

	private ushort HapticPower = 800;

	public Rigidbody BulletObj;
	public Transform BulletPos;

	void Start () 
	{
		Obj = GetComponent<SteamVR_TrackedObject> ();
	}

	void Update () 
	{

		device = SteamVR_Controller.Input ((int)Obj.index);

		// Trigger 
		TpX = device.GetAxis (TriggerButton).x;
		TpY = device.GetAxis (TriggerButton).y;


		TriggerButtonDown = device.GetPressDown (TriggerButton);
		TriggerButtonUp = device.GetPressUp (TriggerButton);
		TriggerButtonPressed = device.GetPress(TriggerButton);
		if (TriggerButtonDown) {
			Debug.Log (" 트리거 버튼 눌려짐.");
			FireObj ();

		}

		if (TriggerButtonPressed) {

			Hatic ();
		}
	}


	private void Hatic()
	{
		device.TriggerHapticPulse (HapticPower);
	}

	private void FireObj()
	{
		Rigidbody bulletIns;

		bulletIns = Instantiate (BulletObj,BulletPos.position,BulletPos.rotation) as Rigidbody;

		bulletIns.AddForce (BulletPos.forward * 1000);
	} 

}
