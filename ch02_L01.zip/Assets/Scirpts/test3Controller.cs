﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class test3Controller : MonoBehaviour {

	private SteamVR_TrackedObject Obj;
	private SteamVR_Controller.Device device;
	private Valve.VR.EVRButtonId TriggerButton = Valve.VR.EVRButtonId.k_EButton_SteamVR_Trigger;
	private Valve.VR.EVRButtonId GripButton = Valve.VR.EVRButtonId.k_EButton_Grip;
	public bool TriggerButtonDown = false;
	public bool TriggerButtonUp = false;
	public bool TriggerButtonPressed = false;
	public bool GripButtonDown = false;
	public bool GripButtonUp = false;
	public bool GripButtonPressed = false;

	void Start () 
	{
		Obj = GetComponent<SteamVR_TrackedObject> ();
	}

	void Update () 
	{        
		device = SteamVR_Controller.Input ((int)Obj.index);
		// Trigger 
		TriggerButtonDown = device.GetPressDown (TriggerButton);
		TriggerButtonUp = device.GetPressUp (TriggerButton);
		TriggerButtonPressed = device.GetPress(TriggerButton);
		if (TriggerButtonDown) {
			Debug.Log (" 트리거 버튼 눌려짐.");
		}
		if (TriggerButtonUp) {
			Debug.Log (" 트리거 버튼 놓아짐.");
		}
		if (TriggerButtonPressed) {
			Debug.Log (" 트리거 버튼 계속 눌린 상태임.");
		}
		// Grip
		GripButtonDown = device.GetPressDown (GripButton);
		GripButtonUp = device.GetPressUp (GripButton);
		GripButtonPressed = device.GetPress(GripButton);
		if (GripButtonDown) {
			Debug.Log (" 그립 버튼 눌려짐.");
		}
		if (GripButtonUp) {
			Debug.Log (" 그립 버튼 놓아짐.");
		}
		if (GripButtonPressed) {
			Debug.Log (" 그립 버튼 계속 눌린 상태임.");
		}

	}

}
