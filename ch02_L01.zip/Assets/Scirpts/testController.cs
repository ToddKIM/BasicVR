﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class testController : MonoBehaviour {

	private SteamVR_TrackedObject Obj;
	private SteamVR_Controller.Device device;
	private Valve.VR.EVRButtonId TriggerButton = Valve.VR.EVRButtonId.k_EButton_SteamVR_Trigger;
	public bool TriggerButtonDown = false;

	void Start () 
	{
		Obj = GetComponent<SteamVR_TrackedObject> ();
	}

	void Update () 
	{
		device = SteamVR_Controller.Input ((int)Obj.index);
		TriggerButtonDown = device.GetPressDown (TriggerButton);

		if (TriggerButtonDown) {
			Debug.Log (" 트리거 버튼 눌려짐.");
		}
	}

}
