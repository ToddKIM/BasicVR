﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RayCube : MonoBehaviour {

	Ray ray;
	RaycastHit hit;

	void Update () {

		// 마우스 왼쪽 버튼 클릭 할 때 
		if (Input.GetMouseButtonDown (0)) {
			// 마우스 클릭 된 위치에 ray 만들기 
			ray.origin = transform.position;
			ray.direction = transform.right;
			// 만들어진 ray로 hit 된 곳이 있는지 확인 하기.
			if (Physics.Raycast (ray, out hit)) {
				Debug.Log ("Hit");
			}

		}

	}
}
