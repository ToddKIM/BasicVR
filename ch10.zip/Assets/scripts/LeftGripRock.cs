﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LeftGripRock : MonoBehaviour {
	public Rigidbody Body;
	private bool isTrigger = false;
	private SteamVR_TrackedObject controller;
	private SteamVR_Controller.Device device;
	private Vector3 PrevControllerPos;

	void Start()
	{
		controller = GetComponent<SteamVR_TrackedObject> ();
		PrevControllerPos = controller.transform.localPosition;
	}
	void Update () {
		device = SteamVR_Controller.Input ((int)controller.index);	
		if (isTrigger && device.GetPress (Valve.VR.EVRButtonId.k_EButton_SteamVR_Trigger)) {
			Body.transform.position += (PrevControllerPos - controller.transform.localPosition);
			Body.useGravity = false;
			Body.isKinematic = true;
		} else {
			Body.useGravity = true;
			Body.isKinematic = false;
		}
		PrevControllerPos = controller.transform.localPosition;
	}

	void OnTriggerEnter()
	{
		isTrigger = true;
	}

	void OnTriggerExit()
	{
		isTrigger = false;
	}
}
