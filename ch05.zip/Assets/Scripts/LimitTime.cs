﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LimitTime : MonoBehaviour {

	private Slider sd;

	private float TimeRemain = 10f;


	void Start () {
		sd = GetComponent<Slider> ();	
	}

	void Update ()
	{
		TimeRemain -= Time.deltaTime;
		sd.value = TimeRemain;
		if (TimeRemain <= 0f)
		{
			EndRound();
		}
	}

	void EndRound()
	{
		//Application.LoadLevel (Application.loadedLevel);
		Application.LoadLevel ("Lose");
	}
}
