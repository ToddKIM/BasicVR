﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Flying : MonoBehaviour {

	public Transform head;

	public SteamVR_TrackedObject rightHand;

	private bool isFlying = false;


	void Update () {


		var rDevice = SteamVR_Controller.Input ((int)rightHand.index);


		if (rDevice.GetTouchDown (SteamVR_Controller.ButtonMask.Trigger)) {
			isFlying = !isFlying;
		}

		if (isFlying) {


			Vector3 rightDir = rightHand.transform.position - head.position;

			Vector3 dir = rightDir; 
			transform.position += (dir*0.01f);
		}

	}
}
