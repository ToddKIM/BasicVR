﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Flying3 : MonoBehaviour {

	public Transform head;

	public SteamVR_TrackedObject rightHand;
	public SteamVR_TrackedObject leftHand;

	private bool isFlying = false;

	public GameObject HeadBody;

	void Update () {


		var rDevice = SteamVR_Controller.Input ((int)rightHand.index);
		var lDevice = SteamVR_Controller.Input ((int)leftHand.index);

		if (lDevice.GetTouchDown (SteamVR_Controller.ButtonMask.Trigger)||rDevice.GetTouchDown (SteamVR_Controller.ButtonMask.Trigger)) {
			isFlying = !isFlying;
		}

		if (isFlying) {


			Vector3 rightDir = rightHand.transform.position - head.position;
			Vector3 leftDir = leftHand.transform.position - head.position;

			Vector3 dir = rightDir+leftDir; 
			transform.position += (dir*0.01f);
		}

	}
}
