﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Title : MonoBehaviour {

	public SteamVR_TrackedObject rightHand;

	private bool isFlying = false;


	void Update () {


		var rDevice = SteamVR_Controller.Input ((int)rightHand.index);


		if (rDevice.GetTouchDown (SteamVR_Controller.ButtonMask.Trigger)) {
			
			Application.LoadLevel ("Main");
		}


	}
}
