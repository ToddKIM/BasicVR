﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class test14Controller : MonoBehaviour {

	private SteamVR_TrackedObject Obj;
	private SteamVR_Controller.Device device;
	private Valve.VR.EVRButtonId TriggerButton = Valve.VR.EVRButtonId.k_EButton_SteamVR_Trigger;
	public bool TriggerButtonDown = false;
	public bool TriggerButtonUp = false;
	private FixedJoint Fjoint;
	public GameObject Rcube;
	void Start () 
	{
		Obj = GetComponent<SteamVR_TrackedObject> ();
		Fjoint = GetComponent<FixedJoint> ();
	}
	void Update () 
	{
		device = SteamVR_Controller.Input ((int)Obj.index);
		TriggerButtonDown = device.GetPressDown (TriggerButton);
		TriggerButtonUp = device.GetPressUp (TriggerButton);
		if (TriggerButtonDown) {
			Debug.Log (" 트리거 버튼 눌려짐.");
			Fjoint.connectedBody = Rcube.GetComponent<Rigidbody> ();
		} 
		if (TriggerButtonUp) {
			Debug.Log (" 트리거 버튼 떼어짐.");
			Fjoint.connectedBody = null;
		}
	} 

}
