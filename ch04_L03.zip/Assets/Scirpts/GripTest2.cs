﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GripTest2 : MonoBehaviour {

	private SteamVR_TrackedObject Obj;
	private SteamVR_Controller.Device device;
	private Valve.VR.EVRButtonId TriggerButton = Valve.VR.EVRButtonId.k_EButton_SteamVR_Trigger;
	public bool TriggerButtonDown = false;
	public bool TriggerButtonUp = false;
	//fixed 조인트 사용하기 위해서 
	private FixedJoint Fjoint;
	// 외부에서 적용되는 것을 보기 위해서
	public GameObject ExObj;
	// 던지는 부분 체크 
	private bool ThrowFlg;
	private Rigidbody Rigid;

	void Start () 
	{
		// SteamVR_TrackedObjcect에 대한 컴포넌트 
		Obj = GetComponent<SteamVR_TrackedObject> ();
		// FixedJoint 컴포넌트 연결 
		Fjoint = GetComponent<FixedJoint> ();
	}
	void Update () 
	{
		// Obj.index 번호로 부터 컴트롤러 가져옴.
		device = SteamVR_Controller.Input ((int)Obj.index);
		// 트리거 버튼 down
		TriggerButtonDown = device.GetPressDown (TriggerButton);
		// 트리거 버튼 up
		TriggerButtonUp = device.GetPressUp (TriggerButton);
		if (TriggerButtonDown) {
			Debug.Log (" 트리거 버튼 눌려짐.");
			// 외부 오브젝트가 있다면 
			if (ExObj != null) {
				// Fixed Joint 와 연결 
				Fjoint.connectedBody = ExObj.GetComponent<Rigidbody> ();
				ThrowFlg = false;
				Rigid = null;
			} else {
				Fjoint.connectedBody = null;
			}		
		}
		if (TriggerButtonUp) {
			Debug.Log (" 트리거 버튼 떼어짐.");		
			// 던지기 위한 Rigidbody를 Rigid에 옮겨 놓음.
			Rigid = Fjoint.connectedBody;
			// fixed joint 는 null 로 초기화
			Fjoint.connectedBody = null;
			ThrowFlg = true;	
		}

		if (ThrowFlg) {
			Transform origin;
			// 컨트롤러 오브젝트가 있다면
			if (Obj.origin != null) {
				origin = Obj.origin;

			} else {
				origin = Obj.transform.parent;
			}

			// 만약 origin 이 있다면 
			if (origin != null) {
				// 컨트롤러의 velocity를 local -> global 로 바꾸어 Rigid의 velocity로 준다. 
				Rigid.velocity = origin.TransformVector (device.velocity);
				// 각 속도 마찬가지.
				Rigid.angularVelocity = origin.TransformVector (device.angularVelocity * 0.3f);
			}
			else {
				// 컨트롤러 velocity 로 준다. 
				Rigid.velocity = device.velocity;
				Rigid.angularVelocity = device.angularVelocity * 0.3f;
			}
			Rigid.maxAngularVelocity = Rigid.angularVelocity.magnitude;

			ThrowFlg = false;
		}

	} 
	void OnTriggerStay(Collider other)
	{        
		ExObj = other.gameObject;
	}
	void OnTriggerExit(Collider other)
	{
		ExObj = null;
	} 
}
