﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BalloonTest : MonoBehaviour {

	public GameObject PrefabObj;
	private ConstantForce cf;

	void Start () {
		Instantiate(PrefabObj);
		cf = PrefabObj.gameObject.GetComponent<ConstantForce> ();
	}

	void Update () {    
		cf.force = new Vector3(0,10,0);
	}

}
