﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Balloon : MonoBehaviour {
	
	private ConstantForce cf;

	void Start () {		
		cf = gameObject.GetComponent<ConstantForce> ();
	}

	void Update () {    
		cf.force = new Vector3(0,10,0);
	}
}
