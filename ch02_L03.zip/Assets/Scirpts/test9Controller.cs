﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class test9Controller : MonoBehaviour {

	private SteamVR_TrackedObject Obj;
	private SteamVR_Controller.Device device;
	private Valve.VR.EVRButtonId TouchpadButton = Valve.VR.EVRButtonId.k_EButton_SteamVR_Touchpad;

	private PrimitiveType currentType = PrimitiveType.Sphere;

	public float TpX;
	public float TpY;
	public bool TouchpadButtonPressed = false;

	private ushort HapticPower = 500;

	public GameObject CubeObj;    // 외부에서 cube를 가져오기 위해

	void Start () 
	{
		Obj = GetComponent<SteamVR_TrackedObject> ();
	}

	void Update () 
	{

		device = SteamVR_Controller.Input ((int)Obj.index);

		TouchpadButtonPressed = device.GetPress (TouchpadButton);
		TpX = device.GetAxis (TouchpadButton).x;
		TpY = device.GetAxis (TouchpadButton).y;

		if (TouchpadButtonPressed) {

			if ((TpY > 0.3f) && (TpX > 0.3f)) {
				Debug.Log ("Up&Right");
				device.TriggerHapticPulse (HapticPower);
			} else if ((TpY < -0.3f) && (TpX > 0.3f)) {
				Debug.Log ("Down&Right");
			} else if ((TpY < -0.3f) && (TpX < -0.3f)) {
				Debug.Log ("Down&Left");
				MakeCubObj ();
			} else {
				Debug.Log ("Up&Left");
				SpawnObj ();
			}

		} 
	}

	private void SpawnObj()
	{
		var spawnedObj = GameObject.CreatePrimitive(currentType);
		spawnedObj.transform.position = transform.position;
		spawnedObj.transform.rotation = transform.rotation;
		spawnedObj.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
	}
	private void MakeCubObj()
	{
		Instantiate (CubeObj,transform.position,transform.rotation);
	} 

}
