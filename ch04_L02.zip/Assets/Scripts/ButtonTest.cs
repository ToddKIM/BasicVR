﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class ButtonTest : MonoBehaviour {

	private const float sp = 0.1f;
	public float distance;
	private int direction = -1;

	public static bool chkButton = false;
	public static bool TriggerOnFlg = false;

	void Start () {
		ResetDistance();
	}

	void Update()
	{		
		if (chkButton) {
			StartCoroutine("MoveDown");
		}
		if (TriggerOnFlg) {
			GetComponent<Renderer> ().material.color = Color.yellow;
		} else {
			GetComponent<Renderer> ().material.color = Color.red;
		}
	}


	IEnumerator MoveDown() {
		while (distance > 0) {
			IncMove();
			yield return null;
		}
		yield return StartCoroutine("MoveUp");
	}

	IEnumerator MoveUp() {
		direction *= -1;
		ResetDistance();
		while (distance > 0) {
			IncMove();
			yield return null;
		}
		direction *= -1;
		ResetDistance();
	}

	void IncMove() {
		float inc = Time.deltaTime * sp;
		inc = Mathf.Min(inc, distance);
		gameObject.transform.Translate(0, inc * direction, 0);
		distance -= inc;
	}

	void ResetDistance() {
		distance = 0.03f;
	}

}


