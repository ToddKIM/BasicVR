﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GripButton : MonoBehaviour {

	private SteamVR_TrackedObject Obj;
	private SteamVR_Controller.Device device;
	private Valve.VR.EVRButtonId TriggerButton = Valve.VR.EVRButtonId.k_EButton_SteamVR_Trigger;

	public bool TriggerButtonDown = false;
	private bool TriggerOn = false;


	void Start () {
		Obj = GetComponent<SteamVR_TrackedObject> ();    
	}    

	void Update () {
		device = SteamVR_Controller.Input ((int)Obj.index);
		TriggerButtonDown = device.GetPressDown (TriggerButton);

		if (TriggerButtonDown && ButtonTest.TriggerOnFlg) {
			Debug.Log (" Button Down ");

			ButtonTest.chkButton = true;

		} else {
			ButtonTest.chkButton = false;
		}
	}


	void OnTriggerStay( Collider other)
	{
		Debug.Log (" Trigger On "); 
		ButtonTest.TriggerOnFlg = true;
	}

	void OnTriggerExit(Collider other)
	{
		ButtonTest.TriggerOnFlg = false;
	}
}

