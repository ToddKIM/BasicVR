﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(LineRenderer))]
public class ParabolicRenderer : MonoBehaviour {

	// 초기 각도 
	public float Angle;
	// 초기 속도 
	public float Velocity;
	// 선에 대한 해상도 
	public int Resolution = 10;

	// 라디안 각도 
	float RadianAngle;
	// 중력 
	float g;
	// 최대 거리 
	float MaxDistance; 

	LineRenderer lineRenderer;

	void Awake()
	{
		lineRenderer = GetComponent<LineRenderer> ();
		// y축 중력 값의 절대값 
		g = Mathf.Abs (Physics.gravity.y);	
	}

	void Update()
	{
		RenderPara ();
	}

	// 선을 보여준다. 
	void RenderPara()
	{
		lineRenderer.SetVertexCount (Resolution + 1);
		lineRenderer.SetPositions (CalcParaArray ());
	}

	// 배열로 만들어 준다. 
	Vector3[] CalcParaArray ()
	{
		Vector3[] ParaArray = new Vector3[Resolution + 1];
		// 라디안 각도로 바꾼다.
		RadianAngle = Mathf.Deg2Rad * Angle;
		// 최대 거리
		MaxDistance = (Velocity * Velocity * Mathf.Sin (2 * RadianAngle)) / g;

		for (int i = 0; i <= Resolution; i++) {
			float p = (float)i / (float)Resolution;
			// 각 x, y vector3 값을 가져온다. 
			ParaArray [i] = CalcParaPoint (p,MaxDistance);
		}
		return ParaArray;
	}

	// 위치를 계산 한다. 
	Vector3 CalcParaPoint(float p, float maxDistance)
	{
		// 구간 정보(t)에 따른 x 값 
		float x = p * maxDistance;
		// x 에 따른 y 의 값
	    float y = Mathf.Tan (RadianAngle) *x - ((g * x * x) / (2 * Velocity * Velocity * Mathf.Cos (RadianAngle) * Mathf.Cos (RadianAngle)));
		return new Vector3 (x, y);
	}
}
