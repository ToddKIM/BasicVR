﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class linetest : MonoBehaviour {

	// 외부 위치 값 정보 
	public Transform target;
	// 기본 색 
	public Color c1 = Color.yellow;

	void Start()
	{
		// 컴포넌트를 첨부하기 위함. 
		LineRenderer lineRenderer = gameObject.AddComponent<LineRenderer>();
		// 기본 material 을 정해 주어야 보라색으로 안 보임.
		lineRenderer.material = new Material(Shader.Find("Particles/Additive"));
		// 선의 너비를 결정함.
		lineRenderer.widthMultiplier = 0.1f;
		// 선의 시작 색
		lineRenderer.startColor = c1;
		// 선의 끝 색
		lineRenderer.endColor = c1;
	}

	void Update()
	{
		// Start() 함수에서 Addcomponent로 만들어준 LineRenderer를 다시 불러옮.
		LineRenderer lineRenderer = GetComponent<LineRenderer>();
		// 마우스 좌 클릭 할때
		if (Input.GetMouseButton (0)) {
			// 시작은 자신의 위치 
			lineRenderer.SetPosition (0, transform.position);
			// 끝은 목표 위치.
			//lineRenderer.SetPosition (1, target.position);		
			lineRenderer.SetPosition (1, Input.mousePosition-transform.position);
		} else {
			// 끝을 자신의 위치로 바꾼다. 
			lineRenderer.SetPosition(1,transform.position);
		}
	}

}
