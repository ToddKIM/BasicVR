﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ContinuousLine : MonoBehaviour {

	private LineRenderer lr;

	void Start()
	{
		lr = GetComponent<LineRenderer>();

		Vector3[] positions = new Vector3[4];
		positions[0] = new Vector3(0f, 0f, 0.0f);
		positions[1] = new Vector3(2.0f, 2.0f, 0.0f);
		positions[2] = new Vector3(6.0f, -2.0f, 0.0f);
		positions[3] = new Vector3(8.0f, 0f, 0.0f);
		lr.positionCount = positions.Length;
		lr.SetPositions(positions);	
	}

}
